# Calculadora-JavaScript-Simples
Calculadora simples usando HTML, CSS e JAVASCRIPT, para colecarf em prática o minicurso ministrado pela série START-OneBitCode con tendo tres aulas vizando os pontos importantes e como funciona cada um deles.

Feito na https://codepen.io/Amanda-Santos-the-builder/pen/JjeyPWE

![Calculadora JavaScript Simples](https://github.com/pand4a/Calculadora-JavaScript-Simples/assets/124163398/a5fc9f11-68d4-4fdd-bb1d-5239a9bea900)
 
 Projeto https://github.com/pand4a/Calculadora-JavaScript-Simples.git
